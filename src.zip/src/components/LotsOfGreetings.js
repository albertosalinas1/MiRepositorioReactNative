import Ract from 'react';

import { Text, View } from 'react-native';
import Greeting from "./Greetings";

const LotsOfGreetings = () => {
    return (
    <View >
    <Greeting name='Rexxar' />
    <Greeting name='Jaina' />
    <Greeting name='Valeera' />
    </View>
    )
};

export default LotsOfGreetings;
   